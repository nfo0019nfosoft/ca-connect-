# Firebase Setup Guide for MediBook

## Quick Setup Steps

### 1. Firebase Console Setup
1. Go to https://console.firebase.google.com
2. Create new project: "medibook-hospital-booking"
3. Enable Firestore Database
4. Enable Firebase Hosting
5. Enable Cloud Functions

### 2. Service Account Key
1. Go to Project Settings → Service Accounts
2. Click "Generate new private key"
3. Save as `serviceAccountKey.json` in project root

### 3. Local Setup
```bash
# Install Firebase CLI
npm install -g firebase-tools

# Login to Firebase
firebase login

# Initialize project
firebase init
# Select: Functions and Hosting
# Choose Python runtime
# Configure hosting rewrites to functions
```

### 4. Create Configuration Files

**firebase.json** (create manually):
```json
{
  "hosting": {
    "public": "public",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [{"source": "**", "function": "app"}]
  },
  "functions": {
    "source": "functions",
    "runtime": "python310",
    "predeploy": ["pip install -r requirements.txt --target $RESOURCE_DIR"]
  }
}
```

**.firebaserc** (create manually):
```json
{"projects": {"default": "your-project-name"}}
```

### 5. Deploy Commands
```bash
# Deploy functions
firebase deploy --only functions

# Deploy hosting
firebase deploy --only hosting

# Deploy both
firebase deploy
```

### 6. Environment Variables
Set in Firebase Console → Project Settings → Functions Configuration:
- FLASK_ENV=production
- SECRET_KEY=your-secret-key
- JWT_SECRET_KEY=your-jwt-secret
- RAZORPAY_KEY_ID=your-razorpay-key
- RAZORPAY_KEY_SECRET=your-razorpay-secret
- ADMIN_COMMISSION_PERCENT=10

### 7. Access Your App
After deployment, your app will be available at:
- https://your-project-name.web.app
- https://your-project-name.firebaseapp.com

## Troubleshooting
- Ensure serviceAccountKey.json is in project root
- Check all required files exist
- Verify Firebase project is properly configured
- Check function logs for errors: `firebase functions:log`
