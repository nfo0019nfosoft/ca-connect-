import os
import json
from firebase_functions import https_fn
from flask import Flask, request, jsonify
from firebase_admin import credentials, firestore
import firebase_admin
from app.firestore_service import firestore_service
from app.config import config

# Initialize Firebase Admin
if not firebase_admin._apps:
    if os.path.exists('serviceAccountKey.json'):
        cred = credentials.Certificate('serviceAccountKey.json')
    else:
        cred = credentials.ApplicationDefault()
    firebase_admin.initialize_app(cred)

# Create Flask app
app = Flask(__name__)
app.config.from_object(config['production'])

# Import routes
from app.auth import bp as auth_bp
from app.hospitals import bp as hospitals_bp
from app.services import bp as services_bp
from app.appointments import bp as appointments_bp
from app.payments import bp as payments_bp
from app.admin import bp as admin_bp

# Register blueprints
app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(hospitals_bp, url_prefix='/api/hospitals')
app.register_blueprint(services_bp, url_prefix='/api/services')
app.register_blueprint(appointments_bp, url_prefix='/api/appointments')
app.register_blueprint(payments_bp, url_prefix='/api/payments')
app.register_blueprint(admin_bp, url_prefix='/api/admin')

# Firebase Cloud Function entry point
@https_fn.on_request()
def app_function(req: https_fn.Request) -> https_fn.Response:
    """Main entry point for Firebase Functions"""
    with app.app_context():
        # Handle CORS
        response = app(req.environ.get('HTTP_X_FORWARDED_FOR', req.method), 
                         req.get_data(), 
                         req.headers, 
                         req.environ.get('QUERY_STRING', ''))
        
        # Add CORS headers
        response.headers['Access-Control-Allow-Origin'] = '*'
        response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS'
        response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'
        
        return response

# Health check endpoint
@app.route('/health')
def health_check():
    return jsonify({
        'status': 'healthy',
        'timestamp': firestore.firestore.SERVER_TIMESTAMP
    })

# Static file serving for Firebase Hosting
@app.route('/static/<path:filename>')
def static_files(filename):
    return app.send_from_directory('static', filename)

# Template rendering
@app.route('/')
def index():
    return app.render_template('patient/index.html')

@app.route('/hospitals')
def hospitals_list():
    return app.render_template('patient/hospitals.html')

@app.route('/hospitals/<hospital_id>')
def hospital_detail(hospital_id):
    hospital = firestore_service.get_hospital_by_id(hospital_id)
    if hospital:
        services = firestore_service.get_services_by_hospital(hospital_id)
        return app.render_template('patient/hospital_detail.html', 
                             hospital=hospital, services=services)
    return "Hospital not found", 404

@app.route('/booking/<hospital_id>')
def booking_page(hospital_id):
    hospital = firestore_service.get_hospital_by_id(hospital_id)
    if hospital:
        return app.render_template('patient/booking.html', hospital=hospital)
    return "Hospital not found", 404

@app.route('/auth/login')
def login_page():
    return app.render_template('patient/login.html')

@app.route('/auth/register')
def register_page():
    return app.render_template('patient/register.html')

@app.route('/about')
def about():
    return app.render_template('patient/about.html')

@app.route('/contact')
def contact():
    return app.render_template('patient/contact.html')

@app.route('/privacy')
def privacy():
    return app.render_template('patient/privacy.html')

@app.route('/terms')
def terms():
    return app.render_template('patient/terms.html')

if __name__ == '__main__':
    app.run(debug=False)
