#!/usr/bin/env python
import os
from app import create_app, db
from app.models import User, Hospital, Service, Appointment, Payment

app = create_app(os.getenv('FLASK_ENV') or 'development')

@app.shell_context_processor
def make_shell_context():
    return {'db': db, 'User': User, 'Hospital': Hospital, 'Service': Service, 'Appointment': Appointment, 'Payment': Payment}

if __name__ == '__main__':
    app.run(debug=True)
