# Deployment Guide for MediBook Hospital Booking System

## Option 1: Heroku Deployment

### Prerequisites
- Heroku CLI installed
- Heroku account
- Git

### Steps

1. **Install Heroku CLI**
   ```bash
   # Download from https://devcenter.heroku.com/articles/heroku-cli
   # Or use npm: npm install -g heroku
   ```

2. **Login to Heroku**
   ```bash
   heroku login
   ```

3. **Initialize Git Repository**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   ```

4. **Create Heroku App**
   ```bash
   heroku create your-app-name
   ```

5. **Set Environment Variables**
   ```bash
   heroku config:set FLASK_ENV=production
   heroku config:set SECRET_KEY=your-secret-key
   heroku config:set JWT_SECRET_KEY=your-jwt-secret
   heroku config:set ADMIN_COMMISSION_PERCENT=10
   heroku config:set RAZORPAY_KEY_ID=your-razorpay-key
   heroku config:set RAZORPAY_KEY_SECRET=your-razorpay-secret
   heroku config:set FIREBASE_CONFIG=your-firebase-config
   ```

6. **Provision PostgreSQL Database**
   ```bash
   heroku addons:create heroku-postgresql:hobby-dev
   ```

7. **Deploy Application**
   ```bash
   git push heroku main
   ```

8. **Run Database Migrations**
   ```bash
   heroku run python -m flask db upgrade
   ```

## Option 2: Vercel Deployment

### Prerequisites
- Vercel CLI installed
- Vercel account

### Steps

1. **Install Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Login to Vercel**
   ```bash
   vercel login
   ```

3. **Create vercel.json Configuration**
   ```json
   {
     "version": 2,
     "builds": [
       {
         "src": "run.py",
         "use": "@vercel/python"
       }
     ],
     "routes": [
       {
         "src": "/(.*)",
         "dest": "run.py"
       }
     ]
   }
   ```

4. **Deploy Application**
   ```bash
   vercel --prod
   ```

5. **Set Environment Variables**
   ```bash
   vercel env add FLASK_ENV production
   vercel env add SECRET_KEY your-secret-key
   vercel env add JWT_SECRET_KEY your-jwt-secret
   # Add other environment variables
   ```

## Option 3: PythonAnywhere Deployment

### Prerequisites
- PythonAnywhere account

### Steps

1. **Create PythonAnywhere Account**
   - Sign up at https://www.pythonanywhere.com/

2. **Create Web Application**
   - Go to Web tab → Add a new web app
   - Choose Flask framework
   - Select Python 3.9

3. **Upload Your Code**
   - Use the Files tab to upload your project
   - Or clone from Git repository

4. **Install Dependencies**
   ```bash
   pip install -r requirements.txt
   ```

5. **Configure WSGI File**
   - Edit the WSGI configuration file
   - Point to your Flask application

6. **Set Environment Variables**
   - Go to Web tab → Variables
   - Add all required environment variables

7. **Reload Web App**
   - Click the reload button

## Option 4: DigitalOcean/Traditional VPS

### Prerequisites
- VPS with Ubuntu/CentOS
- Domain name (optional)

### Steps

1. **Install Dependencies**
   ```bash
   sudo apt update
   sudo apt install python3 python3-pip python3-venv nginx
   ```

2. **Setup Application**
   ```bash
   git clone your-repo
   cd your-repo
   python3 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt
   ```

3. **Configure Gunicorn**
   ```bash
   gunicorn --bind 0.0.0.0:8000 run:app
   ```

4. **Setup Nginx**
   - Configure Nginx as reverse proxy
   - Point to your application

5. **Setup Systemd Service**
   - Create systemd service for automatic startup

## Environment Variables Required

Copy these from your `.env` file:

```bash
FLASK_ENV=production
SECRET_KEY=your-production-secret-key
JWT_SECRET_KEY=your-production-jwt-secret
DATABASE_URL=your-production-database-url
RAZORPAY_KEY_ID=your-razorpay-key-id
RAZORPAY_KEY_SECRET=your-razorpay-key-secret
ADMIN_COMMISSION_PERCENT=10
FIREBASE_CONFIG=your-firebase-config
```

## Production Checklist

- [ ] Set DEBUG=False in production
- [ ] Use PostgreSQL instead of SQLite
- [ ] Configure proper logging
- [ ] Set up SSL/HTTPS
- [ ] Configure backup strategy
- [ ] Monitor application performance
- [ ] Set up error monitoring (Sentry, etc.)

## Troubleshooting

### Common Issues

1. **Database Connection Errors**
   - Check DATABASE_URL environment variable
   - Ensure database is running and accessible

2. **Import Errors**
   - Verify all dependencies are installed
   - Check Python version compatibility

3. **Static Files Not Loading**
   - Configure static file serving
   - Check file permissions

4. **Environment Variables Missing**
   - Double-check all required variables are set
   - Restart application after adding variables

## Monitoring and Maintenance

### Health Checks
- Add health check endpoint
- Monitor application uptime
- Set up alerts for errors

### Backups
- Regular database backups
- File system backups
- Configuration backups

### Updates
- Regular dependency updates
- Security patches
- Application updates
