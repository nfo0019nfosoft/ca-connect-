# Firebase Deployment Guide for MediBook

## Overview
This guide shows how to deploy the MediBook Flask application to Firebase Functions with Firebase Hosting, using Firestore as the database.

## Prerequisites
- Firebase CLI installed
- Firebase project created
- Node.js installed

## Setup Steps

### 1. Install Firebase CLI
```bash
npm install -g firebase-tools
```

### 2. Login to Firebase
```bash
firebase login
```

### 3. Initialize Firebase Project
```bash
cd e:\hostipal_pro\backend
firebase init
```
- Choose: Functions and Hosting
- Select Python as runtime
- Configure hosting to rewrite to functions

### 4. Set Up Project Structure
```bash
mkdir functions
mkdir public
```

### 5. Required Files to Create

#### firebase.json (create manually)
```json
{
  "hosting": {
    "public": "public",
    "ignore": ["firebase.json", "**/.*", "**/node_modules/**"],
    "rewrites": [{"source": "**", "function": "app"}]
  },
  "functions": {
    "source": "functions",
    "runtime": "python310",
    "predeploy": ["pip install -r requirements.txt --target $RESOURCE_DIR"]
  }
}
```

#### functions/main.py (already created)
- Contains Firebase Functions entry point
- Integrates Flask app with Firebase Functions

#### functions/requirements.txt (already created)
- Contains Python dependencies for Firebase Functions

#### serviceAccountKey.json (create manually)
- Download from Firebase Console → Project Settings → Service Accounts
- Place in project root

### 6. Copy Application Files
```bash
cp -r app functions/
cp run.py functions/
cp .env.example functions/
```

### 7. Set Up Static Files for Hosting
```bash
mkdir public/static
cp -r app/static public/
cp -r app/templates public/
```

### 8. Environment Variables
Set these in Firebase Console → Project Settings → Functions Configuration:
```
FLASK_ENV=production
SECRET_KEY=your-production-secret
JWT_SECRET_KEY=your-jwt-secret
RAZORPAY_KEY_ID=your-razorpay-key
RAZORPAY_KEY_SECRET=your-razorpay-secret
ADMIN_COMMISSION_PERCENT=10
FIREBASE_CONFIG=your-firebase-config
```

### 9. Deploy Application
```bash
# Deploy functions first
firebase deploy --only functions

# Then deploy hosting
firebase deploy --only hosting

# Or deploy both at once
firebase deploy
```

## Firestore Database Setup

### Collections Structure
- `users`: User accounts and profiles
- `hospitals`: Hospital information and details
- `services`: Services offered by hospitals
- `appointments`: Patient appointments
- `payments`: Payment records and transactions

### Security Rules
Create Firestore security rules in Firebase Console:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Users can read/write their own profile
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    
    // Anyone can read hospitals and services
    match /hospitals/{hospitalId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    match /services/{serviceId} {
      allow read: if true;
      allow write: if request.auth != null;
    }
    
    // Users can read/write their own appointments
    match /appointments/{appointmentId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.patient_id;
    }
    
    // Users can read/write their own payments
    match /payments/{paymentId} {
      allow read, write: if request.auth != null && 
        request.auth.uid == resource.data.patient_id;
    }
  }
}
```

## Testing the Deployment

### 1. Local Testing
```bash
firebase emulators:start
```

### 2. Function Testing
```bash
firebase functions:shell
```

### 3. Access Your Application
After deployment, your app will be available at:
- `https://your-project-name.web.app`
- `https://your-project-name.firebaseapp.com`

## Migration from SQLite to Firestore

### Key Changes Made:
1. **Firestore Service Layer**: Created `app/firestore_service.py` to handle all database operations
2. **Updated Routes**: Modified auth routes to use Firestore instead of SQLAlchemy
3. **Firebase Functions Entry Point**: Created `functions/main.py` for Firebase Functions deployment
4. **Configuration Updates**: Added Firebase dependencies and configuration

### Benefits of Firestore:
- **Scalability**: Automatically scales with your application
- **Real-time Updates**: Built-in real-time data synchronization
- **Offline Support**: Built-in offline data persistence
- **Security**: Granular security rules
- **No Server Management**: Fully managed database service

## Troubleshooting

### Common Issues:
1. **Import Errors**: Ensure all dependencies are in functions/requirements.txt
2. **CORS Issues**: Check CORS headers in Firebase Functions
3. **Environment Variables**: Verify all required variables are set
4. **Firestore Permissions**: Check security rules and user authentication
5. **Cold Starts**: Firebase Functions may have cold start delays

### Debugging:
```bash
# View function logs
firebase functions:log

# Test specific function
firebase functions:shell --function app
```

## Production Considerations

### Performance:
- Enable Cloud Functions caching
- Optimize Firestore queries
- Use appropriate indexes

### Security:
- Implement proper security rules
- Validate all user inputs
- Use HTTPS for all communications

### Monitoring:
- Set up Firebase Performance Monitoring
- Monitor function execution times
- Track error rates and user metrics

## Cost Management

### Free Tier Limits:
- Cloud Functions: 125,000 invocations/month
- Firestore: 1 GiB storage, 50,000 reads/day, 20,000 writes/day
- Hosting: 10 GiB storage, 360 MB/day bandwidth

### Optimization Tips:
- Use efficient queries
- Implement proper indexing
- Cache frequently accessed data
- Monitor and optimize function cold starts
