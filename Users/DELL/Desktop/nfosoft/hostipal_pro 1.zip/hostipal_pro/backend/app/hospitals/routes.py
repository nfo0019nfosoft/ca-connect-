from flask import request, jsonify
from flask_jwt_extended import jwt_required
from app.hospitals import bp
from app.models import Hospital
from app.schemas import hospital_schema, hospitals_schema
from app.utils import log_request, log_error, format_response, validate_json_content_type, admin_required, paginate_query
from app.extensions import db

@bp.route('', methods=['GET'])
def get_hospitals():
    log_request()
    try:
        # Get query parameters
        search = request.args.get('q', '')
        category = request.args.get('category', '')
        specialty = request.args.get('specialty', '')
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = Hospital.query.filter_by(is_active=True)
        
        # Apply filters
        if search:
            query = query.filter(Hospital.name.ilike(f'%{search}%'))
        
        if category:
            query = query.filter(Hospital.category == category)
        
        if specialty:
            query = query.filter(Hospital.specialties.contains([specialty]))
        
        # Order by name
        query = query.order_by(Hospital.name)
        
        # Paginate
        result = paginate_query(query, page, per_page)
        
        # Serialize items
        result['items'] = hospitals_schema.dump(result['items'])
        
        return format_response(data=result)
        
    except Exception as e:
        log_error(e, "get_hospitals")
        return format_response(error='Failed to fetch hospitals', status=500)

@bp.route('/<int:hospital_id>', methods=['GET'])
def get_hospital(hospital_id):
    log_request()
    try:
        hospital = Hospital.query.filter_by(id=hospital_id, is_active=True).first()
        
        if not hospital:
            return format_response(error='Hospital not found', status=404)
        
        return format_response(data=hospital_schema.dump(hospital))
        
    except Exception as e:
        log_error(e, "get_hospital")
        return format_response(error='Failed to fetch hospital', status=500)

@bp.route('', methods=['POST'])
@jwt_required()
@admin_required
@validate_json_content_type
def create_hospital():
    log_request()
    try:
        data = request.get_json()
        
        # Validate input
        hospital_data = hospital_schema.load(data)
        
        # Create hospital
        hospital = Hospital(**hospital_data.__dict__)
        
        db.session.add(hospital)
        db.session.commit()
        
        return format_response(
            data=hospital_schema.dump(hospital),
            message='Hospital created successfully',
            status=201
        )
        
    except Exception as e:
        log_error(e, "create_hospital")
        db.session.rollback()
        return format_response(error='Failed to create hospital', status=500)

@bp.route('/<int:hospital_id>', methods=['PUT'])
@jwt_required()
@admin_required
@validate_json_content_type
def update_hospital(hospital_id):
    log_request()
    try:
        hospital = Hospital.query.get(hospital_id)
        
        if not hospital:
            return format_response(error='Hospital not found', status=404)
        
        data = request.get_json()
        
        # Validate input
        hospital_data = hospital_schema.load(data, partial=True)
        
        # Update fields
        for key, value in hospital_data.__dict__.items():
            if hasattr(hospital, key) and key != 'id':
                setattr(hospital, key, value)
        
        db.session.commit()
        
        return format_response(
            data=hospital_schema.dump(hospital),
            message='Hospital updated successfully'
        )
        
    except Exception as e:
        log_error(e, "update_hospital")
        db.session.rollback()
        return format_response(error='Failed to update hospital', status=500)

@bp.route('/<int:hospital_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_hospital(hospital_id):
    log_request()
    try:
        hospital = Hospital.query.get(hospital_id)
        
        if not hospital:
            return format_response(error='Hospital not found', status=404)
        
        # Soft delete - just mark as inactive
        hospital.is_active = False
        db.session.commit()
        
        return format_response(message='Hospital deleted successfully')
        
    except Exception as e:
        log_error(e, "delete_hospital")
        db.session.rollback()
        return format_response(error='Failed to delete hospital', status=500)

@bp.route('/categories', methods=['GET'])
def get_categories():
    """Get all unique hospital categories"""
    log_request()
    try:
        categories = db.session.query(Hospital.category).distinct().all()
        categories = [cat[0] for cat in categories if cat[0]]
        
        return format_response(data=categories)
        
    except Exception as e:
        log_error(e, "get_categories")
        return format_response(error='Failed to fetch categories', status=500)

@bp.route('/specialties', methods=['GET'])
def get_specialties():
    """Get all unique specialties across hospitals"""
    log_request()
    try:
        hospitals = Hospital.query.filter_by(is_active=True).all()
        specialties = set()
        
        for hospital in hospitals:
            if hospital.specialties:
                specialties.update(hospital.specialties)
        
        specialties = sorted(list(specialties))
        
        return format_response(data=specialties)
        
    except Exception as e:
        log_error(e, "get_specialties")
        return format_response(error='Failed to fetch specialties', status=500)
