from flask import Flask
from flask_jwt_extended import JWTManager
from flask_bcrypt import Bcrypt
from flask_migrate import Migrate
from app.config import config
from app.extensions import db, bcrypt, jwt, migrate
from app.auth import bp as auth_bp
from app.hospitals import bp as hospitals_bp
from app.services import bp as services_bp
from app.appointments import bp as appointments_bp
from app.payments import bp as payments_bp
from app.admin import bp as admin_bp
import os
from dotenv import load_dotenv

load_dotenv()

def create_app(config_name='development'):
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    
    # Initialize extensions
    db.init_app(app)
    bcrypt.init_app(app)
    jwt.init_app(app)
    migrate.init_app(app, db)
    
    # Register blueprints
    app.register_blueprint(auth_bp, url_prefix='/api/auth')
    app.register_blueprint(hospitals_bp, url_prefix='/api/hospitals')
    app.register_blueprint(services_bp, url_prefix='/api/services')
    app.register_blueprint(appointments_bp, url_prefix='/api/appointments')
    app.register_blueprint(payments_bp, url_prefix='/api/payments')
    app.register_blueprint(admin_bp)
    
    # Main routes for patient UI
    @app.route('/')
    def index():
        from flask import render_template
        return render_template('patient/index.html')
    
    @app.route('/about')
    def about():
        from flask import render_template
        return render_template('patient/about.html')
    
    @app.route('/contact')
    def contact():
        from flask import render_template
        return render_template('patient/contact.html')
    
    @app.route('/privacy')
    def privacy():
        from flask import render_template
        return render_template('patient/privacy.html')
    
    @app.route('/terms')
    def terms():
        from flask import render_template
        return render_template('patient/terms.html')
    
    @app.route('/hospitals')
    def hospitals_list():
        from flask import render_template, request
        # Get hospitals with filters
        from app.models import Hospital, Service
        query = Hospital.query
        
        # Search filter
        search = request.args.get('q', '')
        if search:
            query = query.filter(Hospital.name.ilike(f'%{search}%'))
        
        # Category filter
        category = request.args.get('category', '')
        if category:
            query = query.filter(Hospital.category == category)
        
        # Specialty filter
        specialty = request.args.get('specialty', '')
        if specialty:
            query = query.filter(Hospital.specialties.contains([specialty]))
        
        # Pagination
        page = request.args.get('page', 1, type=int)
        per_page = 12
        hospitals = query.paginate(page=page, per_page=per_page, error_out=False)
        
        # Get all unique categories and specialties for filters
        categories = db.session.query(Hospital.category).distinct().all()
        categories = [cat[0] for cat in categories if cat[0]]
        
        all_hospitals = Hospital.query.all()
        specialties = set()
        for hospital in all_hospitals:
            specialties.update(hospital.specialties)
        specialties = sorted(list(specialties))
        
        return render_template('patient/hospitals.html', 
                             hospitals=hospitals, 
                             categories=categories,
                             specialties=specialties,
                             search=search,
                             selected_category=category,
                             selected_specialty=specialty)
    
    @app.route('/hospitals/<int:hospital_id>')
    def hospital_detail(hospital_id):
        from flask import render_template
        from app.models import Hospital, Service
        hospital = Hospital.query.get_or_404(hospital_id)
        services = Service.query.filter_by(hospital_id=hospital_id).all()
        return render_template('patient/hospital_detail.html', hospital=hospital, services=services)
    
    @app.route('/booking/<int:hospital_id>')
    def booking_page(hospital_id):
        from flask import render_template, session, redirect, url_for, flash
        from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity
        from app.models import Hospital, Service
        
        try:
            verify_jwt_in_request()
            patient_id = get_jwt_identity()
        except:
            flash('Please login to book an appointment', 'warning')
            session['next'] = f'/booking/{hospital_id}'
            return redirect(url_for('auth.login_page'))
        
        hospital = Hospital.query.get_or_404(hospital_id)
        services = Service.query.filter_by(hospital_id=hospital_id).all()
        return render_template('patient/booking.html', hospital=hospital, services=services)
    
    return app
