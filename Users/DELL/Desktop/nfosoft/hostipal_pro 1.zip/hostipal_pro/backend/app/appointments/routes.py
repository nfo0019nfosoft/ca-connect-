from flask import request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.appointments import bp
from app.models import Appointment, User, Hospital, Service
from app.schemas import appointment_schema, appointments_schema
from app.utils import log_request, log_error, format_response, validate_json_content_type, patient_required, admin_required, paginate_query
from app.extensions import db
from datetime import datetime, date, time

@bp.route('', methods=['GET'])
@jwt_required()
@admin_required
def get_appointments():
    log_request()
    try:
        # Get query parameters
        status = request.args.get('status', '')
        hospital_id = request.args.get('hospital_id', type=int)
        patient_id = request.args.get('patient_id', type=int)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = Appointment.query
        
        # Apply filters
        if status:
            query = query.filter(Appointment.status == status)
        
        if hospital_id:
            query = query.filter(Appointment.hospital_id == hospital_id)
        
        if patient_id:
            query = query.filter(Appointment.patient_id == patient_id)
        
        # Order by appointment date and time
        query = query.order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc())
        
        # Paginate
        result = paginate_query(query, page, per_page)
        
        # Serialize items
        result['items'] = appointments_schema.dump(result['items'])
        
        return format_response(data=result)
        
    except Exception as e:
        log_error(e, "get_appointments")
        return format_response(error='Failed to fetch appointments', status=500)

@bp.route('/my', methods=['GET'])
@jwt_required()
@patient_required
def get_my_appointments():
    """Get current patient's appointments"""
    log_request()
    try:
        current_user_id = get_jwt_identity()
        
        # Get query parameters
        status = request.args.get('status', '')
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query for current user's appointments
        query = Appointment.query.filter_by(patient_id=current_user_id)
        
        # Apply status filter
        if status:
            query = query.filter(Appointment.status == status)
        
        # Order by appointment date and time
        query = query.order_by(Appointment.appointment_date.desc(), Appointment.appointment_time.desc())
        
        # Paginate
        result = paginate_query(query, page, per_page)
        
        # Serialize items
        result['items'] = appointments_schema.dump(result['items'])
        
        return format_response(data=result)
        
    except Exception as e:
        log_error(e, "get_my_appointments")
        return format_response(error='Failed to fetch appointments', status=500)

@bp.route('/<int:appointment_id>', methods=['GET'])
@jwt_required()
def get_appointment(appointment_id):
    log_request()
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        appointment = Appointment.query.get(appointment_id)
        
        if not appointment:
            return format_response(error='Appointment not found', status=404)
        
        # Check permissions: admins can see all, patients can only see their own
        if not user.is_admin and appointment.patient_id != current_user_id:
            return format_response(error='Access denied', status=403)
        
        return format_response(data=appointment_schema.dump(appointment))
        
    except Exception as e:
        log_error(e, "get_appointment")
        return format_response(error='Failed to fetch appointment', status=500)

@bp.route('', methods=['POST'])
@jwt_required()
@patient_required
@validate_json_content_type
def create_appointment():
    log_request()
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        # Validate input
        appointment_data = appointment_schema.load(data)
        
        # Check if hospital and service exist
        hospital = Hospital.query.filter_by(id=appointment_data.hospital_id, is_active=True).first()
        if not hospital:
            return format_response(error='Hospital not found', status=404)
        
        service = Service.query.filter_by(id=appointment_data.service_id, hospital_id=appointment_data.hospital_id, is_active=True).first()
        if not service:
            return format_response(error='Service not found', status=404)
        
        # Create appointment
        appointment = Appointment(
            patient_id=current_user_id,
            hospital_id=appointment_data.hospital_id,
            service_id=appointment_data.service_id,
            appointment_date=appointment_data.appointment_date,
            appointment_time=appointment_data.appointment_time,
            notes=appointment_data.notes,
            patient_name=appointment_data.patient_name,
            patient_phone=appointment_data.patient_phone,
            patient_email=appointment_data.patient_email,
            fcm_token=data.get('fcm_token')  # For push notifications
        )
        
        db.session.add(appointment)
        db.session.commit()
        
        return format_response(
            data=appointment_schema.dump(appointment),
            message='Appointment created successfully',
            status=201
        )
        
    except Exception as e:
        log_error(e, "create_appointment")
        db.session.rollback()
        return format_response(error='Failed to create appointment', status=500)

@bp.route('/<int:appointment_id>/status', methods=['PUT'])
@jwt_required()
@admin_required
@validate_json_content_type
def update_appointment_status(appointment_id):
    log_request()
    try:
        appointment = Appointment.query.get(appointment_id)
        
        if not appointment:
            return format_response(error='Appointment not found', status=404)
        
        data = request.get_json()
        new_status = data.get('status')
        
        if not new_status:
            return format_response(error='Status is required', status=400)
        
        valid_statuses = ['scheduled', 'confirmed', 'completed', 'cancelled', 'no-show']
        if new_status not in valid_statuses:
            return format_response(error=f'Invalid status. Must be one of: {", ".join(valid_statuses)}', status=400)
        
        appointment.status = new_status
        db.session.commit()
        
        return format_response(
            data=appointment_schema.dump(appointment),
            message=f'Appointment status updated to {new_status}'
        )
        
    except Exception as e:
        log_error(e, "update_appointment_status")
        db.session.rollback()
        return format_response(error='Failed to update appointment status', status=500)

@bp.route('/<int:appointment_id>', methods=['PUT'])
@jwt_required()
@validate_json_content_type
def update_appointment(appointment_id):
    log_request()
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        appointment = Appointment.query.get(appointment_id)
        
        if not appointment:
            return format_response(error='Appointment not found', status=404)
        
        # Check permissions
        if not user.is_admin and appointment.patient_id != current_user_id:
            return format_response(error='Access denied', status=403)
        
        data = request.get_json()
        
        # Update allowed fields
        if 'notes' in data:
            appointment.notes = data['notes']
        
        if 'fcm_token' in data:
            appointment.fcm_token = data['fcm_token']
        
        # Only admins can change appointment date/time
        if user.is_admin:
            if 'appointment_date' in data:
                appointment.appointment_date = datetime.strptime(data['appointment_date'], '%Y-%m-%d').date()
            if 'appointment_time' in data:
                appointment.appointment_time = datetime.strptime(data['appointment_time'], '%H:%M').time()
        
        db.session.commit()
        
        return format_response(
            data=appointment_schema.dump(appointment),
            message='Appointment updated successfully'
        )
        
    except Exception as e:
        log_error(e, "update_appointment")
        db.session.rollback()
        return format_response(error='Failed to update appointment', status=500)

@bp.route('/<int:appointment_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_appointment(appointment_id):
    log_request()
    try:
        appointment = Appointment.query.get(appointment_id)
        
        if not appointment:
            return format_response(error='Appointment not found', status=404)
        
        db.session.delete(appointment)
        db.session.commit()
        
        return format_response(message='Appointment deleted successfully')
        
    except Exception as e:
        log_error(e, "delete_appointment")
        db.session.rollback()
        return format_response(error='Failed to delete appointment', status=500)
