import os
import json
from datetime import datetime
from typing import List, Dict, Optional, Any
import firebase_admin
from firebase_admin import credentials, firestore
from werkzeug.security import generate_password_hash, check_password_hash

class FirestoreService:
    def __init__(self):
        self._db = None
        self._initialize_firestore()
    
    def _initialize_firestore(self):
        """Initialize Firebase Admin SDK and Firestore client"""
        try:
            if not firebase_admin._apps:
                # For local development, use service account key
                if os.path.exists('serviceAccountKey.json'):
                    cred = credentials.Certificate('serviceAccountKey.json')
                else:
                    # For Firebase Functions, use default credentials
                    cred = credentials.ApplicationDefault()
                
                firebase_admin.initialize_app(cred)
            
            self._db = firestore.client()
        except Exception as e:
            print(f"Error initializing Firestore: {e}")
            self._db = None
    
    @property
    def db(self):
        """Get Firestore database instance"""
        return self._db
    
    # User operations
    def create_user(self, user_data: Dict[str, Any]) -> str:
        """Create a new user in Firestore"""
        if not self._db:
            raise Exception("Firestore not initialized")
        
        # Hash password
        if 'password' in user_data:
            user_data['password'] = generate_password_hash(user_data['password'])
        
        # Add timestamps
        user_data['created_at'] = datetime.utcnow()
        user_data['updated_at'] = datetime.utcnow()
        
        doc_ref = self._db.collection('users').add(user_data)
        return doc_ref[1].id
    
    def get_user_by_email(self, email: str) -> Optional[Dict[str, Any]]:
        """Get user by email"""
        if not self._db:
            return None
        
        users = self._db.collection('users').where('email', '==', email).limit(1).get()
        
        for user in users:
            user_data = user.to_dict()
            user_data['id'] = user.id
            return user_data
        
        return None
    
    def get_user_by_id(self, user_id: str) -> Optional[Dict[str, Any]]:
        """Get user by ID"""
        if not self._db:
            return None
        
        user_doc = self._db.collection('users').document(user_id).get()
        
        if user_doc.exists:
            user_data = user_doc.to_dict()
            user_data['id'] = user_doc.id
            return user_data
        
        return None
    
    def update_user(self, user_id: str, update_data: Dict[str, Any]) -> bool:
        """Update user data"""
        if not self._db:
            return False
        
        # Hash password if present
        if 'password' in update_data:
            update_data['password'] = generate_password_hash(update_data['password'])
        
        update_data['updated_at'] = datetime.utcnow()
        
        try:
            self._db.collection('users').document(user_id).update(update_data)
            return True
        except Exception as e:
            print(f"Error updating user: {e}")
            return False
    
    # Hospital operations
    def create_hospital(self, hospital_data: Dict[str, Any]) -> str:
        """Create a new hospital"""
        if not self._db:
            raise Exception("Firestore not initialized")
        
        hospital_data['created_at'] = datetime.utcnow()
        hospital_data['updated_at'] = datetime.utcnow()
        
        doc_ref = self._db.collection('hospitals').add(hospital_data)
        return doc_ref[1].id
    
    def get_hospitals(self, limit: int = 10, offset: int = 0, 
                     category: str = None, specialty: str = None, 
                     search: str = None) -> Dict[str, Any]:
        """Get hospitals with filters and pagination"""
        if not self._db:
            return {'items': [], 'total': 0, 'pages': 0}
        
        query = self._db.collection('hospitals')
        
        # Apply filters
        if category:
            query = query.where('category', '==', category)
        
        if search:
            # Simple text search (you might want to use Algolia for better search)
            query = query.where('name', '>=', search).where('name', '<=', search + '\uf8ff')
        
        # Get total count
        total_docs = len(list(query.get()))
        
        # Apply pagination
        query = query.limit(limit).offset(offset)
        
        hospitals = []
        for doc in query.get():
            hospital_data = doc.to_dict()
            hospital_data['id'] = doc.id
            hospitals.append(hospital_data)
        
        pages = (total_docs + limit - 1) // limit
        
        return {
            'items': hospitals,
            'total': total_docs,
            'pages': pages
        }
    
    def get_hospital_by_id(self, hospital_id: str) -> Optional[Dict[str, Any]]:
        """Get hospital by ID"""
        if not self._db:
            return None
        
        hospital_doc = self._db.collection('hospitals').document(hospital_id).get()
        
        if hospital_doc.exists:
            hospital_data = hospital_doc.to_dict()
            hospital_data['id'] = hospital_doc.id
            return hospital_data
        
        return None
    
    # Service operations
    def create_service(self, service_data: Dict[str, Any]) -> str:
        """Create a new service"""
        if not self._db:
            raise Exception("Firestore not initialized")
        
        service_data['created_at'] = datetime.utcnow()
        service_data['updated_at'] = datetime.utcnow()
        
        doc_ref = self._db.collection('services').add(service_data)
        return doc_ref[1].id
    
    def get_services_by_hospital(self, hospital_id: str) -> List[Dict[str, Any]]:
        """Get all services for a hospital"""
        if not self._db:
            return []
        
        services = []
        query = self._db.collection('services').where('hospital_id', '==', hospital_id)
        
        for doc in query.get():
            service_data = doc.to_dict()
            service_data['id'] = doc.id
            services.append(service_data)
        
        return services
    
    def get_service_by_id(self, service_id: str) -> Optional[Dict[str, Any]]:
        """Get service by ID"""
        if not self._db:
            return None
        
        service_doc = self._db.collection('services').document(service_id).get()
        
        if service_doc.exists:
            service_data = service_doc.to_dict()
            service_data['id'] = service_doc.id
            return service_data
        
        return None
    
    # Appointment operations
    def create_appointment(self, appointment_data: Dict[str, Any]) -> str:
        """Create a new appointment"""
        if not self._db:
            raise Exception("Firestore not initialized")
        
        appointment_data['created_at'] = datetime.utcnow()
        appointment_data['updated_at'] = datetime.utcnow()
        appointment_data['status'] = 'scheduled'
        
        doc_ref = self._db.collection('appointments').add(appointment_data)
        return doc_ref[1].id
    
    def get_appointments_by_patient(self, patient_id: str) -> List[Dict[str, Any]]:
        """Get all appointments for a patient"""
        if not self._db:
            return []
        
        appointments = []
        query = self._db.collection('appointments').where('patient_id', '==', patient_id)
        
        for doc in query.get():
            appointment_data = doc.to_dict()
            appointment_data['id'] = doc.id
            appointments.append(appointment_data)
        
        return appointments
    
    def get_appointment_by_id(self, appointment_id: str) -> Optional[Dict[str, Any]]:
        """Get appointment by ID"""
        if not self._db:
            return None
        
        appointment_doc = self._db.collection('appointments').document(appointment_id).get()
        
        if appointment_doc.exists:
            appointment_data = appointment_doc.to_dict()
            appointment_data['id'] = appointment_doc.id
            return appointment_data
        
        return None
    
    def update_appointment(self, appointment_id: str, update_data: Dict[str, Any]) -> bool:
        """Update appointment"""
        if not self._db:
            return False
        
        update_data['updated_at'] = datetime.utcnow()
        
        try:
            self._db.collection('appointments').document(appointment_id).update(update_data)
            return True
        except Exception as e:
            print(f"Error updating appointment: {e}")
            return False
    
    # Payment operations
    def create_payment(self, payment_data: Dict[str, Any]) -> str:
        """Create a new payment"""
        if not self._db:
            raise Exception("Firestore not initialized")
        
        payment_data['created_at'] = datetime.utcnow()
        payment_data['updated_at'] = datetime.utcnow()
        
        doc_ref = self._db.collection('payments').add(payment_data)
        return doc_ref[1].id
    
    def get_payment_by_id(self, payment_id: str) -> Optional[Dict[str, Any]]:
        """Get payment by ID"""
        if not self._db:
            return None
        
        payment_doc = self._db.collection('payments').document(payment_id).get()
        
        if payment_doc.exists:
            payment_data = payment_doc.to_dict()
            payment_data['id'] = payment_doc.id
            return payment_data
        
        return None
    
    def update_payment(self, payment_id: str, update_data: Dict[str, Any]) -> bool:
        """Update payment"""
        if not self._db:
            return False
        
        update_data['updated_at'] = datetime.utcnow()
        
        try:
            self._db.collection('payments').document(payment_id).update(update_data)
            return True
        except Exception as e:
            print(f"Error updating payment: {e}")
            return False
    
    # Utility operations
    def get_categories(self) -> List[str]:
        """Get all hospital categories"""
        if not self._db:
            return []
        
        categories = set()
        hospitals = self._db.collection('hospitals').get()
        
        for hospital in hospitals:
            hospital_data = hospital.to_dict()
            if 'category' in hospital_data:
                categories.add(hospital_data['category'])
        
        return list(categories)
    
    def get_specialties(self) -> List[str]:
        """Get all hospital specialties"""
        if not self._db:
            return []
        
        specialties = set()
        hospitals = self._db.collection('hospitals').get()
        
        for hospital in hospitals:
            hospital_data = hospital.to_dict()
            if 'specialties' in hospital_data:
                specialties.update(hospital_data['specialties'])
        
        return list(specialties)

# Global Firestore service instance
firestore_service = FirestoreService()
