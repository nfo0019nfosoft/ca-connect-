from flask import request, jsonify, current_app
from flask_jwt_extended import jwt_required, get_jwt_identity
from app.payments import bp
from app.models import Payment, Appointment, User
from app.schemas import payment_schema, payments_schema, payment_create_order_schema, payment_verify_schema
from app.utils import log_request, log_error, format_response, validate_json_content_type, patient_required, admin_required, generate_razorpay_order, verify_razorpay_payment, log_payment, paginate_query
from app.extensions import db

@bp.route('', methods=['GET'])
@jwt_required()
@admin_required
def get_payments():
    log_request()
    try:
        # Get query parameters
        status = request.args.get('status', '')
        hospital_id = request.args.get('hospital_id', type=int)
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = Payment.query
        
        # Apply filters
        if status:
            query = query.filter(Payment.status == status)
        
        if hospital_id:
            query = query.join(Appointment).filter(Appointment.hospital_id == hospital_id)
        
        # Order by creation date
        query = query.order_by(Payment.created_at.desc())
        
        # Paginate
        result = paginate_query(query, page, per_page)
        
        # Serialize items
        result['items'] = payments_schema.dump(result['items'])
        
        return format_response(data=result)
        
    except Exception as e:
        log_error(e, "get_payments")
        return format_response(error='Failed to fetch payments', status=500)

@bp.route('/<int:payment_id>', methods=['GET'])
@jwt_required()
def get_payment(payment_id):
    log_request()
    try:
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        
        payment = Payment.query.get(payment_id)
        
        if not payment:
            return format_response(error='Payment not found', status=404)
        
        # Check permissions: admins can see all, patients can only see their own
        if not user.is_admin and payment.appointment.patient_id != current_user_id:
            return format_response(error='Access denied', status=403)
        
        return format_response(data=payment_schema.dump(payment))
        
    except Exception as e:
        log_error(e, "get_payment")
        return format_response(error='Failed to fetch payment', status=500)

@bp.route('/create-order', methods=['POST'])
@jwt_required()
@patient_required
@validate_json_content_type
def create_order():
    log_request()
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        # Validate input
        order_data = payment_create_order_schema.load(data)
        
        # Check if appointment exists and belongs to current user
        appointment = Appointment.query.get(order_data.appointment_id)
        if not appointment:
            return format_response(error='Appointment not found', status=404)
        
        if appointment.patient_id != current_user_id:
            return format_response(error='Access denied', status=403)
        
        # Check if payment already exists for this appointment
        existing_payment = Payment.query.filter_by(appointment_id=appointment.id).first()
        if existing_payment and existing_payment.status == 'completed':
            return format_response(error='Payment already completed for this appointment', status=400)
        
        # Generate Razorpay order
        razorpay_order = generate_razorpay_order(order_data.amount, f"appointment_{appointment.id}")
        
        # Calculate commission
        commission_percent = current_app.config['ADMIN_COMMISSION_PERCENT']
        commission_amount, hospital_amount = Payment.calculate_commission(order_data.amount, commission_percent)
        
        # Create payment record
        payment = Payment(
            appointment_id=appointment.id,
            amount=order_data.amount,
            admin_commission_percent=commission_percent,
            admin_commission_amount=commission_amount,
            hospital_amount=hospital_amount,
            razorpay_order_id=razorpay_order['id'],
            status='pending'
        )
        
        db.session.add(payment)
        db.session.commit()
        
        # Log payment creation
        log_payment({
            'payment_id': payment.id,
            'appointment_id': appointment.id,
            'amount': order_data.amount,
            'razorpay_order_id': razorpay_order['id']
        }, 'order_created')
        
        return format_response(
            data={
                'payment': payment_schema.dump(payment),
                'razorpay_order': razorpay_order,
                'razorpay_key_id': current_app.config['RAZORPAY_KEY_ID']
            },
            message='Payment order created successfully',
            status=201
        )
        
    except Exception as e:
        log_error(e, "create_order")
        db.session.rollback()
        return format_response(error='Failed to create payment order', status=500)

@bp.route('/verify', methods=['POST'])
@jwt_required()
@patient_required
@validate_json_content_type
def verify_payment():
    log_request()
    try:
        current_user_id = get_jwt_identity()
        data = request.get_json()
        
        # Validate input
        verify_data = payment_verify_schema.load(data)
        
        # Find payment by Razorpay order ID
        payment = Payment.query.filter_by(razorpay_order_id=verify_data['razorpay_order_id']).first()
        if not payment:
            return format_response(error='Payment order not found', status=404)
        
        # Check if payment belongs to current user
        if payment.appointment.patient_id != current_user_id:
            return format_response(error='Access denied', status=403)
        
        # Check if payment is already completed
        if payment.status == 'completed':
            return format_response(error='Payment already verified', status=400)
        
        # Verify Razorpay signature
        is_valid = verify_razorpay_payment(
            verify_data['razorpay_order_id'],
            verify_data['razorpay_payment_id'],
            verify_data['razorpay_signature']
        )
        
        if not is_valid:
            payment.status = 'failed'
            db.session.commit()
            
            log_payment({
                'payment_id': payment.id,
                'razorpay_order_id': verify_data['razorpay_order_id'],
                'error': 'Invalid signature'
            }, 'payment_failed')
            
            return format_response(error='Payment verification failed', status=400)
        
        # Update payment record
        payment.razorpay_payment_id = verify_data['razorpay_payment_id']
        payment.razorpay_signature = verify_data['razorpay_signature']
        payment.status = 'completed'
        
        # Update appointment status
        payment.appointment.status = 'confirmed'
        
        db.session.commit()
        
        # Log successful payment
        log_payment({
            'payment_id': payment.id,
            'appointment_id': payment.appointment_id,
            'amount': payment.amount,
            'commission': payment.admin_commission_amount,
            'hospital_amount': payment.hospital_amount,
            'razorpay_payment_id': verify_data['razorpay_payment_id']
        }, 'payment_completed')
        
        return format_response(
            data=payment_schema.dump(payment),
            message='Payment verified successfully'
        )
        
    except Exception as e:
        log_error(e, "verify_payment")
        db.session.rollback()
        return format_response(error='Payment verification failed', status=500)

@bp.route('/<int:payment_id>/refund', methods=['POST'])
@jwt_required()
@admin_required
@validate_json_content_type
def refund_payment(payment_id):
    log_request()
    try:
        payment = Payment.query.get(payment_id)
        
        if not payment:
            return format_response(error='Payment not found', status=404)
        
        if payment.status != 'completed':
            return format_response(error='Only completed payments can be refunded', status=400)
        
        # In a real implementation, you would integrate with Razorpay refund API
        # For now, we'll just mark it as refunded
        payment.status = 'refunded'
        
        # Update appointment status
        payment.appointment.status = 'cancelled'
        
        db.session.commit()
        
        log_payment({
            'payment_id': payment.id,
            'amount': payment.amount,
            'action': 'refund'
        }, 'payment_refunded')
        
        return format_response(
            data=payment_schema.dump(payment),
            message='Payment refunded successfully'
        )
        
    except Exception as e:
        log_error(e, "refund_payment")
        db.session.rollback()
        return format_response(error='Refund failed', status=500)

@bp.route('/stats', methods=['GET'])
@jwt_required()
@admin_required
def get_payment_stats():
    """Get payment statistics for admin dashboard"""
    log_request()
    try:
        from sqlalchemy import func
        
        # Total revenue
        total_revenue = db.session.query(func.sum(Payment.amount)).filter(Payment.status == 'completed').scalar() or 0
        
        # Total commission earned
        total_commission = db.session.query(func.sum(Payment.admin_commission_amount)).filter(Payment.status == 'completed').scalar() or 0
        
        # Total hospital earnings
        total_hospital_earnings = db.session.query(func.sum(Payment.hospital_amount)).filter(Payment.status == 'completed').scalar() or 0
        
        # Payment counts by status
        payment_counts = db.session.query(
            Payment.status,
            func.count(Payment.id)
        ).group_by(Payment.status).all()
        
        payment_stats = {status: count for status, count in payment_counts}
        
        # Recent payments
        recent_payments = Payment.query.order_by(Payment.created_at.desc()).limit(10).all()
        
        stats = {
            'total_revenue': float(total_revenue),
            'total_commission': float(total_commission),
            'total_hospital_earnings': float(total_hospital_earnings),
            'payment_counts': payment_stats,
            'recent_payments': payments_schema.dump(recent_payments)
        }
        
        return format_response(data=stats)
        
    except Exception as e:
        log_error(e, "get_payment_stats")
        return format_response(error='Failed to fetch payment statistics', status=500)
