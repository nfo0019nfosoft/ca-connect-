from flask import request, jsonify, render_template, redirect, url_for, flash, session, current_app
from flask_jwt_extended import create_access_token, verify_jwt_in_request, get_jwt_identity
from app.admin import bp
from app.models import User, Hospital, Service, Appointment, Payment
from app.schemas import admin_commission_schema
from app.utils import log_request, log_error, format_response, validate_json_content_type, admin_required
from app.extensions import db
from sqlalchemy import func, desc

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('admin/login.html')
    
    # POST request for login
    try:
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            if request.is_json:
                return format_response(error='Email and password are required', status=400)
            flash('Email and password are required', 'error')
            return render_template('admin/login.html')
        
        # Find admin user
        user = User.query.filter_by(email=email, is_admin=True).first()
        
        if not user or not user.check_password(password):
            if request.is_json:
                return format_response(error='Invalid credentials', status=401)
            flash('Invalid credentials', 'error')
            return render_template('admin/login.html')
        
        if not user.is_active:
            if request.is_json:
                return format_response(error='Account is inactive', status=401)
            flash('Account is inactive', 'error')
            return render_template('admin/login.html')
        
        # Create access token
        access_token = create_access_token(identity=user.id)
        
        if request.is_json:
            return format_response(
                data={
                    'access_token': access_token,
                    'user': {
                        'id': user.id,
                        'email': user.email,
                        'name': user.name
                    }
                },
                message='Login successful'
            )
        
        # Store token in session for web interface
        session['admin_token'] = access_token
        flash('Login successful', 'success')
        return redirect(url_for('admin.dashboard'))
        
    except Exception as e:
        log_error(e, "admin_login")
        if request.is_json:
            return format_response(error='Login failed', status=500)
        flash('Login failed', 'error')
        return render_template('admin/login.html')

@bp.route('/logout', methods=['GET', 'POST'])
def logout():
    session.pop('admin_token', None)
    flash('Logged out successfully', 'success')
    return redirect(url_for('admin.login'))

@bp.route('/dashboard')
def dashboard():
    """Admin dashboard"""
    try:
        # Verify admin access
        try:
            verify_jwt_in_request()
            current_user_id = get_jwt_identity()
            user = User.query.get(current_user_id)
            if not user or not user.is_admin:
                flash('Admin access required', 'error')
                return redirect(url_for('admin.login'))
        except:
            flash('Please login to access admin panel', 'error')
            return redirect(url_for('admin.login'))
        
        # Get dashboard statistics
        stats = {}
        
        # Total hospitals
        stats['total_hospitals'] = Hospital.query.filter_by(is_active=True).count()
        
        # Total services
        stats['total_services'] = Service.query.filter_by(is_active=True).count()
        
        # Total appointments
        stats['total_appointments'] = Appointment.query.count()
        
        # Total revenue
        stats['total_revenue'] = db.session.query(func.sum(Payment.amount)).filter(Payment.status == 'completed').scalar() or 0
        
        # Total commission earned
        stats['total_commission'] = db.session.query(func.sum(Payment.admin_commission_amount)).filter(Payment.status == 'completed').scalar() or 0
        
        # Recent appointments
        recent_appointments = Appointment.query.order_by(desc(Appointment.created_at)).limit(10).all()
        
        # Recent payments
        recent_payments = Payment.query.order_by(desc(Payment.created_at)).limit(10).all()
        
        # Top hospitals by revenue
        top_hospitals = db.session.query(
            Hospital.name,
            func.sum(Payment.hospital_amount).label('revenue'),
            func.count(Payment.id).label('payment_count')
        ).join(Payment.hospital).filter(
            Payment.status == 'completed'
        ).group_by(Hospital.id).order_by(desc('revenue')).limit(5).all()
        
        # Appointment status breakdown
        appointment_stats = db.session.query(
            Appointment.status,
            func.count(Appointment.id)
        ).group_by(Appointment.status).all()
        
        return render_template('admin/dashboard.html',
                             stats=stats,
                             recent_appointments=recent_appointments,
                             recent_payments=recent_payments,
                             top_hospitals=top_hospitals,
                             appointment_stats=appointment_stats)
        
    except Exception as e:
        log_error(e, "admin_dashboard")
        flash('Failed to load dashboard', 'error')
        return redirect(url_for('admin.login'))

@bp.route('/hospitals')
def hospitals():
    """Manage hospitals"""
    try:
        # Verify admin access
        verify_jwt_in_request()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            flash('Admin access required', 'error')
            return redirect(url_for('admin.login'))
        
        hospitals = Hospital.query.order_by(Hospital.name).all()
        return render_template('admin/hospitals.html', hospitals=hospitals)
        
    except Exception as e:
        log_error(e, "admin_hospitals")
        flash('Failed to load hospitals', 'error')
        return redirect(url_for('admin.dashboard'))

@bp.route('/services')
def services():
    """Manage services"""
    try:
        # Verify admin access
        verify_jwt_in_request()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            flash('Admin access required', 'error')
            return redirect(url_for('admin.login'))
        
        services = Service.query.order_by(Service.name).all()
        return render_template('admin/services.html', services=services)
        
    except Exception as e:
        log_error(e, "admin_services")
        flash('Failed to load services', 'error')
        return redirect(url_for('admin.dashboard'))

@bp.route('/appointments')
def appointments():
    """Manage appointments"""
    try:
        # Verify admin access
        verify_jwt_in_request()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            flash('Admin access required', 'error')
            return redirect(url_for('admin.login'))
        
        # Get filter parameters
        status = request.args.get('status', '')
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        # Build query
        query = Appointment.query
        
        if status:
            query = query.filter(Appointment.status == status)
        
        # Paginate
        appointments = query.order_by(desc(Appointment.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('admin/appointments.html', 
                             appointments=appointments, 
                             selected_status=status)
        
    except Exception as e:
        log_error(e, "admin_appointments")
        flash('Failed to load appointments', 'error')
        return redirect(url_for('admin.dashboard'))

@bp.route('/payments')
def payments():
    """View payments"""
    try:
        # Verify admin access
        verify_jwt_in_request()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            flash('Admin access required', 'error')
            return redirect(url_for('admin.login'))
        
        # Get filter parameters
        status = request.args.get('status', '')
        page = request.args.get('page', 1, type=int)
        per_page = 20
        
        # Build query
        query = Payment.query
        
        if status:
            query = query.filter(Payment.status == status)
        
        # Paginate
        payments = query.order_by(desc(Payment.created_at)).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return render_template('admin/payments.html', 
                             payments=payments, 
                             selected_status=status)
        
    except Exception as e:
        log_error(e, "admin_payments")
        flash('Failed to load payments', 'error')
        return redirect(url_for('admin.dashboard'))

@bp.route('/settings', methods=['GET', 'POST'])
def settings():
    """Admin settings"""
    try:
        # Verify admin access
        verify_jwt_in_request()
        current_user_id = get_jwt_identity()
        user = User.query.get(current_user_id)
        if not user or not user.is_admin:
            flash('Admin access required', 'error')
            return redirect(url_for('admin.login'))
        
        if request.method == 'GET':
            return render_template('admin/settings.html',
                                 commission_percent=current_app.config['ADMIN_COMMISSION_PERCENT'])
        
        # POST request to update commission
        data = request.get_json() if request.is_json else request.form.to_dict()
        
        # Validate input
        commission_data = admin_commission_schema.load(data)
        
        # In a real application, you would store this in database
        # For now, we'll just return success (would need to restart app to take effect)
        if request.is_json:
            return format_response(message='Commission updated successfully')
        
        flash('Commission updated successfully', 'success')
        return redirect(url_for('admin.settings'))
        
    except Exception as e:
        log_error(e, "admin_settings")
        if request.is_json:
            return format_response(error='Failed to update settings', status=500)
        flash('Failed to update settings', 'error')
        return redirect(url_for('admin.settings'))

@bp.route('/api/login', methods=['POST'])
@validate_json_content_type
def api_login():
    """API endpoint for admin login"""
    try:
        data = request.get_json()
        
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return format_response(error='Email and password are required', status=400)
        
        # Find admin user
        user = User.query.filter_by(email=email, is_admin=True).first()
        
        if not user or not user.check_password(password):
            return format_response(error='Invalid credentials', status=401)
        
        if not user.is_active:
            return format_response(error='Account is inactive', status=401)
        
        # Create access token
        access_token = create_access_token(identity=user.id)
        
        return format_response(
            data={
                'access_token': access_token,
                'user': {
                    'id': user.id,
                    'email': user.email,
                    'name': user.name
                }
            },
            message='Login successful'
        )
        
    except Exception as e:
        log_error(e, "admin_api_login")
        return format_response(error='Login failed', status=500)
