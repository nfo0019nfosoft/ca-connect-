from flask import request, jsonify, render_template, redirect, url_for, flash, session
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from app.auth import bp
from app.schemas import user_schema, user_login_schema
from app.utils import log_request, log_error, format_response, validate_json_content_type
from app.firestore_service import firestore_service

@bp.route('/register', methods=['POST'])
@validate_json_content_type
def register():
    log_request()
    try:
        data = request.get_json()
        
        # Validate input
        user_data = user_schema.load(data)
        
        # Check if user already exists
        existing_user = firestore_service.get_user_by_email(user_data['email'])
        if existing_user:
            return format_response('error', 'User with this email already exists', 409)
        
        # Create new user
        user_id = firestore_service.create_user({
            'name': user_data['name'],
            'email': user_data['email'],
            'phone': user_data['phone'],
            'password': user_data['password'],
            'role': 'patient'
        })
        
        # Get the created user
        user = firestore_service.get_user_by_id(user_id)
        
        # Generate access token
        access_token = create_access_token(identity=user_id)
        
        return format_response('success', 'User registered successfully', 201, {
            'user': user,
            'access_token': access_token
        })
        
    except Exception as e:
        log_error(e, "register")
        return format_response(error='Registration failed', status=500)

@bp.route('/login', methods=['POST'])
@validate_json_content_type
def login():
    log_request()
    try:
        data = request.get_json()
        
        # Validate input
        login_data = user_login_schema.load(data)
        
        # Find user
        user = firestore_service.get_user_by_email(login_data['email'])
        
        if not user:
            return format_response(error='Invalid credentials', status=401)
        
        # Check password (Firestore stores hashed passwords)
        from werkzeug.security import check_password_hash
        if not check_password_hash(user['password'], login_data['password']):
            return format_response(error='Invalid credentials', status=401)
        
        if not user.get('is_active', True):
            return format_response(error='Account is inactive', status=401)
        
        # Create access token
        access_token = create_access_token(identity=user['id'])
        
        return format_response(
            data={
                'user': user,
                'access_token': access_token
            },
            message='Login successful'
        )
        
    except Exception as e:
        log_error(e, "login")
        return format_response(error='Login failed', status=500)

@bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    try:
        current_user_id = get_jwt_identity()
        user = firestore_service.get_user_by_id(current_user_id)
        
        if not user:
            return format_response(error='User not found', status=404)
        
        return format_response(data=user)
        
    except Exception as e:
        log_error(e, "get_current_user")
        return format_response(error='Failed to get user data', status=500)

@bp.route('/update-profile', methods=['PUT'])
@jwt_required()
@validate_json_content_type
def update_profile():
    log_request()
    try:
        current_user_id = get_jwt_identity()
        user = firestore_service.get_user_by_id(current_user_id)
        
        if not user:
            return format_response(error='User not found', status=404)
        
        data = request.get_json()
        
        # Update allowed fields
        update_data = {}
        if 'name' in data:
            update_data['name'] = data['name']
        if 'phone' in data:
            update_data['phone'] = data['phone']
        
        # Update in Firestore
        if update_data:
            firestore_service.update_user(current_user_id, update_data)
            # Get updated user data
            updated_user = firestore_service.get_user_by_id(current_user_id)
        else:
            updated_user = user
        
        return format_response(
            data=updated_user,
            message='Profile updated successfully'
        )
        
    except Exception as e:
        log_error(e, "update_profile")
        return format_response(error='Profile update failed', status=500)

# Web routes for patient login/register pages
@bp.route('/login', methods=['GET'])
def login_page():
    return render_template('patient/login.html')

@bp.route('/register', methods=['GET'])
def register_page():
    return render_template('patient/register.html')

@bp.route('/logout', methods=['GET'])
def logout():
    # For JWT, we typically handle logout on client side by removing token
    # This is just a redirect to home page
    flash('You have been logged out', 'info')
    return redirect(url_for('index'))
