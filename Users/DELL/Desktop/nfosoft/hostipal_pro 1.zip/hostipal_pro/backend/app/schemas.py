from flask_marshmallow import Marshmallow
from marshmallow import fields, validate, validates_schema, ValidationError
from app.models import User, Hospital, Service, Appointment, Payment
from datetime import datetime, date, time

ma = Marshmallow()

class UserSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = User
        load_instance = True
        exclude = ('password_hash',)
    
    password = fields.Str(load_only=True, required=True, validate=validate.Length(min=6))
    email = fields.Email(required=True)
    name = fields.Str(required=True, validate=validate.Length(min=2))

class UserLoginSchema(ma.Schema):
    email = fields.Email(required=True)
    password = fields.Str(required=True)

class HospitalSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Hospital
        load_instance = True
    
    specialties = fields.List(fields.Str())
    facilities = fields.List(fields.Str())
    opening_hours = fields.Dict()
    gallery_images = fields.List(fields.Str())

class ServiceSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Service
        load_instance = True
    
    price = fields.Float(required=True, validate=validate.Range(min=0))
    duration_minutes = fields.Int(required=True, validate=validate.Range(min=1))

class AppointmentSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Appointment
        load_instance = True
    
    appointment_date = fields.Date(required=True)
    appointment_time = fields.Time(required=True)
    patient_name = fields.Str(required=True, validate=validate.Length(min=2))
    patient_phone = fields.Str(required=True, validate=validate.Length(min=10))
    patient_email = fields.Email()
    
    @validates_schema
    def validate_appointment_datetime(self, data, **kwargs):
        if 'appointment_date' in data and 'appointment_time' in data:
            appointment_datetime = datetime.combine(data['appointment_date'], data['appointment_time'])
            if appointment_datetime <= datetime.now():
                raise ValidationError('Appointment must be in the future')

class PaymentSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = Payment
        load_instance = True
    
    amount = fields.Float(required=True, validate=validate.Range(min=1))

class PaymentCreateOrderSchema(ma.Schema):
    amount = fields.Float(required=True, validate=validate.Range(min=1))
    appointment_id = fields.Int(required=True)

class PaymentVerifySchema(ma.Schema):
    razorpay_order_id = fields.Str(required=True)
    razorpay_payment_id = fields.Str(required=True)
    razorpay_signature = fields.Str(required=True)

class AdminCommissionSchema(ma.Schema):
    commission_percent = fields.Float(required=True, validate=validate.Range(min=0, max=100))

# Initialize schemas
user_schema = UserSchema()
users_schema = UserSchema(many=True)
user_login_schema = UserLoginSchema()

hospital_schema = HospitalSchema()
hospitals_schema = HospitalSchema(many=True)

service_schema = ServiceSchema()
services_schema = ServiceSchema(many=True)

appointment_schema = AppointmentSchema()
appointments_schema = AppointmentSchema(many=True)

payment_schema = PaymentSchema()
payments_schema = PaymentSchema(many=True)

payment_create_order_schema = PaymentCreateOrderSchema()
payment_verify_schema = PaymentVerifySchema()
admin_commission_schema = AdminCommissionSchema()
