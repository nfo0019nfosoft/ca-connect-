from flask import Blueprint

bp = Blueprint('hospitals', __name__)

from app.hospitals import routes
