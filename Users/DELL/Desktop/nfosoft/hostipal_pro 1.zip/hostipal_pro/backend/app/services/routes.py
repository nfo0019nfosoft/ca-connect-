from flask import request, jsonify
from flask_jwt_extended import jwt_required
from app.services import bp
from app.models import Service, Hospital
from app.schemas import service_schema, services_schema
from app.utils import log_request, log_error, format_response, validate_json_content_type, admin_required, paginate_query
from app.extensions import db

@bp.route('', methods=['GET'])
def get_services():
    log_request()
    try:
        # Get query parameters
        hospital_id = request.args.get('hospital_id', type=int)
        category = request.args.get('category', '')
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Build query
        query = Service.query.filter_by(is_active=True)
        
        # Apply filters
        if hospital_id:
            query = query.filter(Service.hospital_id == hospital_id)
        
        if category:
            query = query.filter(Service.category == category)
        
        # Order by name
        query = query.order_by(Service.name)
        
        # Paginate
        result = paginate_query(query, page, per_page)
        
        # Serialize items
        result['items'] = services_schema.dump(result['items'])
        
        return format_response(data=result)
        
    except Exception as e:
        log_error(e, "get_services")
        return format_response(error='Failed to fetch services', status=500)

@bp.route('/<int:service_id>', methods=['GET'])
def get_service(service_id):
    log_request()
    try:
        service = Service.query.filter_by(id=service_id, is_active=True).first()
        
        if not service:
            return format_response(error='Service not found', status=404)
        
        return format_response(data=service_schema.dump(service))
        
    except Exception as e:
        log_error(e, "get_service")
        return format_response(error='Failed to fetch service', status=500)

@bp.route('', methods=['POST'])
@jwt_required()
@admin_required
@validate_json_content_type
def create_service():
    log_request()
    try:
        data = request.get_json()
        
        # Validate input
        service_data = service_schema.load(data)
        
        # Check if hospital exists
        hospital = Hospital.query.get(service_data.hospital_id)
        if not hospital:
            return format_response(error='Hospital not found', status=404)
        
        # Create service
        service = Service(**service_data.__dict__)
        
        db.session.add(service)
        db.session.commit()
        
        return format_response(
            data=service_schema.dump(service),
            message='Service created successfully',
            status=201
        )
        
    except Exception as e:
        log_error(e, "create_service")
        db.session.rollback()
        return format_response(error='Failed to create service', status=500)

@bp.route('/<int:service_id>', methods=['PUT'])
@jwt_required()
@admin_required
@validate_json_content_type
def update_service(service_id):
    log_request()
    try:
        service = Service.query.get(service_id)
        
        if not service:
            return format_response(error='Service not found', status=404)
        
        data = request.get_json()
        
        # Validate input
        service_data = service_schema.load(data, partial=True)
        
        # Update fields
        for key, value in service_data.__dict__.items():
            if hasattr(service, key) and key != 'id':
                setattr(service, key, value)
        
        db.session.commit()
        
        return format_response(
            data=service_schema.dump(service),
            message='Service updated successfully'
        )
        
    except Exception as e:
        log_error(e, "update_service")
        db.session.rollback()
        return format_response(error='Failed to update service', status=500)

@bp.route('/<int:service_id>', methods=['DELETE'])
@jwt_required()
@admin_required
def delete_service(service_id):
    log_request()
    try:
        service = Service.query.get(service_id)
        
        if not service:
            return format_response(error='Service not found', status=404)
        
        # Soft delete - just mark as inactive
        service.is_active = False
        db.session.commit()
        
        return format_response(message='Service deleted successfully')
        
    except Exception as e:
        log_error(e, "delete_service")
        db.session.rollback()
        return format_response(error='Failed to delete service', status=500)

@bp.route('/hospital/<int:hospital_id>', methods=['GET'])
def get_hospital_services(hospital_id):
    """Get all services for a specific hospital"""
    log_request()
    try:
        # Check if hospital exists
        hospital = Hospital.query.filter_by(id=hospital_id, is_active=True).first()
        if not hospital:
            return format_response(error='Hospital not found', status=404)
        
        services = Service.query.filter_by(hospital_id=hospital_id, is_active=True).order_by(Service.name).all()
        
        return format_response(data=services_schema.dump(services))
        
    except Exception as e:
        log_error(e, "get_hospital_services")
        return format_response(error='Failed to fetch hospital services', status=500)

@bp.route('/categories', methods=['GET'])
def get_categories():
    """Get all unique service categories"""
    log_request()
    try:
        categories = db.session.query(Service.category).distinct().all()
        categories = [cat[0] for cat in categories if cat[0]]
        
        return format_response(data=categories)
        
    except Exception as e:
        log_error(e, "get_categories")
        return format_response(error='Failed to fetch categories', status=500)
