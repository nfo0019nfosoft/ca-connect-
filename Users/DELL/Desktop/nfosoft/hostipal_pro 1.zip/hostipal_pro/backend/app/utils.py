import logging
import json
from datetime import datetime
from flask import request, jsonify
from functools import wraps
from flask_jwt_extended import verify_jwt_in_request, get_jwt_identity

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def log_request():
    """Log request details"""
    logger.info(f"{request.method} {request.path} - IP: {request.remote_addr}")

def log_payment(payment_data, action):
    """Log payment related actions"""
    logger.info(f"Payment {action}: {json.dumps(payment_data, default=str)}")

def log_error(error, context=""):
    """Log errors with context"""
    logger.error(f"Error in {context}: {str(error)}")

def admin_required(f):
    """Decorator to require admin access"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            verify_jwt_in_request()
            current_user_id = get_jwt_identity()
            from app.models import User
            user = User.query.get(current_user_id)
            if not user or not user.is_admin:
                return jsonify({'error': 'Admin access required'}), 403
            return f(*args, **kwargs)
        except Exception as e:
            log_error(e, "admin_required decorator")
            return jsonify({'error': 'Invalid token'}), 401
    return decorated_function

def patient_required(f):
    """Decorator to require patient access (non-admin)"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        try:
            verify_jwt_in_request()
            current_user_id = get_jwt_identity()
            from app.models import User
            user = User.query.get(current_user_id)
            if not user or user.is_admin:
                return jsonify({'error': 'Patient access required'}), 403
            return f(*args, **kwargs)
        except Exception as e:
            log_error(e, "patient_required decorator")
            return jsonify({'error': 'Invalid token'}), 401
    return decorated_function

def validate_json_content_type(f):
    """Decorator to validate JSON content type"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not request.is_json:
            return jsonify({'error': 'Content-Type must be application/json'}), 400
        return f(*args, **kwargs)
    return decorated_function

def format_response(data=None, message=None, status=200, error=None):
    """Standard API response format"""
    response = {
        'status': 'success' if status < 400 else 'error',
        'message': message,
        'data': data
    }
    if error:
        response['error'] = error
    return jsonify(response), status

def paginate_query(query, page, per_page=20, max_per_page=100):
    """Helper function for pagination"""
    if per_page > max_per_page:
        per_page = max_per_page
    
    paginated = query.paginate(
        page=page, 
        per_page=per_page, 
        error_out=False
    )
    
    return {
        'items': paginated.items,
        'total': paginated.total,
        'pages': paginated.pages,
        'current_page': page,
        'per_page': per_page,
        'has_next': paginated.has_next,
        'has_prev': paginated.has_prev
    }

def generate_razorpay_order(amount, receipt=None):
    """Generate Razorpay order"""
    try:
        import razorpay
        from app.config import Config
        
        client = razorpay.Client(
            auth=(Config.RAZORPAY_KEY_ID, Config.RAZORPAY_KEY_SECRET)
        )
        
        order_data = {
            'amount': int(amount * 100),  # Razorpay expects amount in paise
            'currency': 'INR',
            'receipt': receipt or f"receipt_{datetime.now().timestamp()}",
            'payment_capture': 1
        }
        
        order = client.order.create(order_data)
        return order
    except Exception as e:
        log_error(e, "generate_razorpay_order")
        raise e

def verify_razorpay_payment(razorpay_order_id, razorpay_payment_id, razorpay_signature):
    """Verify Razorpay payment signature"""
    try:
        import razorpay
        from app.config import Config
        
        client = razorpay.Client(
            auth=(Config.RAZORPAY_KEY_ID, Config.RAZORPAY_KEY_SECRET)
        )
        
        params = {
            'razorpay_order_id': razorpay_order_id,
            'razorpay_payment_id': razorpay_payment_id,
            'razorpay_signature': razorpay_signature
        }
        
        client.utility.verify_payment_signature(params)
        return True
    except Exception as e:
        log_error(e, "verify_razorpay_payment")
        return False
