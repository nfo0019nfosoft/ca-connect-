#!/bin/bash

# Firebase Deployment Script for MediBook

echo "Starting Firebase deployment..."

# Check if Firebase CLI is installed
if ! command -v firebase &> /dev/null; then
    echo "Firebase CLI not found. Installing..."
    npm install -g firebase-tools
fi

# Check if service account key exists
if [ ! -f "serviceAccountKey.json" ]; then
    echo "ERROR: serviceAccountKey.json not found!"
    echo "Please download from Firebase Console → Project Settings → Service Accounts"
    exit 1
fi

# Check if firebase.json exists
if [ ! -f "firebase.json" ]; then
    echo "ERROR: firebase.json not found!"
    echo "Please create firebase.json configuration file"
    exit 1
fi

# Deploy functions first
echo "Deploying Firebase Functions..."
firebase deploy --only functions

# Then deploy hosting
echo "Deploying Firebase Hosting..."
firebase deploy --only hosting

echo "Deployment complete!"
echo "Your app is now live at: https://your-project-name.web.app"
